# Tarun Sharma — Portfolio Website

A responsive, dark-futuristic personal portfolio built with plain HTML, CSS, and JavaScript.

## Run locally
1. Extract the folder if downloaded as a ZIP.
2. Open `index.html` in a modern browser.

No build tools or dependencies are required. Google Fonts are loaded online; fallback fonts are provided.

## Customize
- Edit the text and project cards in `index.html`.
- Replace project placeholder statuses with accurate statuses.
- Add real GitHub repository and live-demo URLs when available.
- Adjust the skill bar widths to reflect your actual proficiency.
- The contact form uses `mailto:` and opens the visitor's email app. It does not submit to a server.

## Publish
Upload `index.html` to any static hosting provider that supports HTML pages.
